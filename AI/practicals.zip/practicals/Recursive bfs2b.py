import queue as Q
from RMP import dict_gn, dict_hn

start = 'Arad'
goal = 'Bucharest'
result = ''

def get_fn(citystr):
    # Calculate f(n) = g(n) + h(n)
    cities = citystr.split(",")
    gn = 0
    for ctr in range(len(cities) - 1):  # Calculate g(n) as the path cost so far
        gn += dict_gn[cities[ctr]][cities[ctr + 1]]
    hn = dict_hn[cities[-1]]  # h(n) is the heuristic cost from the current city to the goal
    return hn + gn

def printout(cityq):
    for i in range(cityq.qsize()):
        print(cityq.queue[i])

def expand(cityq):
    global result
    if cityq.empty():
        return
    
    tot, citystr, thiscity = cityq.get()

    if thiscity == goal:
        result = citystr + "::" + str(tot)  # If the goal is found, set the result and return
        return

    print("Expanded city ---------", thiscity)
    
    tempq = Q.PriorityQueue()  # Temporary priority queue to store neighbors
    for cty in dict_gn[thiscity]:
        # Add neighboring cities to the temporary queue with their f(n) values
        tempq.put((get_fn(citystr + ',' + cty), citystr + ',' + cty, cty))
    
    for ctr in range(2):  # Limit to expanding the best 2 options
        if not tempq.empty():
            ctrtot, ctrcitystr, ctrthiscity = tempq.get()
            cityq.put((ctrtot, ctrcitystr, ctrthiscity))  # Add back the best cities to the main queue

    printout(cityq)  # Print the queue's state after expansion
    expand(cityq)  # Continue expanding the next city in the queue

def main():
    cityq = Q.PriorityQueue()
    thiscity = start
    cityq.put((get_fn(start), start, thiscity))  # Initialize the queue with the starting city
    expand(cityq)
    print(result)  # Print the result when the goal is found

main()
