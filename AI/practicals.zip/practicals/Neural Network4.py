import numpy as np

class NeuralNetwork:
    def __init__(self):
        np.random.seed(1)  # Set a seed for reproducibility
        # Initialize synaptic weights with values between -1 and 1
        self.synaptic_weights = 2 * np.random.random((3, 1)) - 1

    # Sigmoid activation function
    def sigmoid(self, x):
        return 1 / (1 + np.exp(-x))

    # Derivative of the sigmoid function
    def sigmoid_derivative(self, x):
        return x * (1 - x)

    # Train the neural network with inputs and expected outputs
    def train(self, training_inputs, training_outputs, training_iterations):
        for iteration in range(training_iterations):
            # Think process (forward pass)
            output = self.think(training_inputs)
            # Calculate error
            error = training_outputs - output
            # Adjust weights according to the error and learning rate
            adjustments = np.dot(training_inputs.T, error * self.sigmoid_derivative(output))
            self.synaptic_weights += adjustments

    # Think (forward pass) function
    def think(self, inputs):
        inputs = inputs.astype(float)  # Ensure the inputs are float
        output = self.sigmoid(np.dot(inputs, self.synaptic_weights))
        return output

# Main program
if __name__ == "__main__":
    # Initialize the neural network
    neural_network = NeuralNetwork()

    print("Beginning Randomly Generated Weights: ")
    print(neural_network.synaptic_weights)

    # Training data: 4 samples with 3 input values and 1 output value
    training_inputs = np.array([[0, 0, 1],
                                [1, 1, 1],
                                [1, 0, 1],
                                [0, 1, 1]])

    training_outputs = np.array([[0, 1, 1, 0]]).T

    # Train the neural network
    neural_network.train(training_inputs, training_outputs, 15000)

    print("Ending Weights After Training: ")
    print(neural_network.synaptic_weights)

    # Take user input and convert to float for the neural network
    user_input_one = float(input("User Input One: "))
    user_input_two = float(input("User Input Two: "))
    user_input_three = float(input("User Input Three: "))

    print(f"Considering New Situation: {user_input_one}, {user_input_two}, {user_input_three}")
    new_input = np.array([user_input_one, user_input_two, user_input_three])
    print("New Output data: ")
    print(neural_network.think(new_input))
