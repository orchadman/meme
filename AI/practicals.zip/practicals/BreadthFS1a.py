import queue as Q
from RMP import dict_gn  # Assuming dict_gn contains the graph as a dictionary

start = 'Arad'
goal = 'Bucharest'

def BFS(city, cityq, visitedq):
    result = city + " "  # Start with the initial city in the result
    cityq.put(city)
    
    while not cityq.empty():
        current_city = cityq.get()
        
        if current_city == goal:
            result += goal  # If goal is found, add it to the result and break
            break

        if current_city not in visitedq.queue:  # Process city if not yet visited
            visitedq.put(current_city)  # Mark city as visited
            
            for each_city in dict_gn[current_city].keys():
                if each_city not in cityq.queue and each_city not in visitedq.queue:
                    cityq.put(each_city)  # Add neighboring city to the queue
                    result += each_city + " "

    return result.strip()  # Return the result without extra spaces

def main():
    cityq = Q.Queue()
    visitedq = Q.Queue()
    
    traversal_result = BFS(start, cityq, visitedq)
    print("BFS Traversal From", start, "to", goal, "is:")
    print(traversal_result)

main()
