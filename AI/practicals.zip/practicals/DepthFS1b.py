import queue as Q
from RMP import dict_gn

start = "Arad"
goal = "Bucharest"
result = ""  # Global result to store the path when goal is found

def DLS(city, visitedstack, startlimit, endlimit):
    global result
    visitedstack.append(city)
    result += city + " "  # Add city to the result

    if city == goal:  # If goal is found, stop recursion
        return 1
    
    if startlimit == endlimit:  # If depth limit is reached, stop further recursion
        return 0

    for eachcity in dict_gn[city].keys():  # Explore adjacent cities
        if eachcity not in visitedstack:
            found = DLS(eachcity, visitedstack, startlimit + 1, endlimit)
            if found:  # If goal is found, stop further exploration
                return found

    visitedstack.pop()  # Backtrack if the city doesn't lead to the goal
    return 0

def IDDFS(city, visitedstack, endlimit):
    global result
    for i in range(endlimit):  # Incrementally increase depth limit
        print("Searching at Limit:", i)
        result = ""  # Reset the result for each depth iteration
        visitedstack.clear()  # Clear the visited stack for each iteration
        found = DLS(city, visitedstack, 0, i)
        
        if found:  # If goal is found, print the result and break
            print("Found")
            break
        else:
            print("Not Found!")
            print(result)  # Print the result for the current depth iteration
            print("______")

def main():
    visitedstack = []  # Initialize an empty visited stack
    IDDFS(start, visitedstack, 9)  # Perform IDDFS with a depth limit of 9
    print("IDDFS Traversal from", start, "to", goal, "is:")
    print(result.strip())  # Print the final result

main()
